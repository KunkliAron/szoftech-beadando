﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Webshop
{
    public static class CurrentSession
    {
        public static int CurrentUserID { get; set; }
    }
}
