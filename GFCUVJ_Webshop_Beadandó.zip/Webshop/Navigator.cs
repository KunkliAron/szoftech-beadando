﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Webshop
{
    public partial class Navigator : Form
    {
        public Navigator()
        {
            InitializeComponent();
        }

        private void button_Order_Click(object sender, EventArgs e)
        {
            Order order = new Order(this);
            this.Hide();
            order.Show();
        }

        private void button_OrderDetails_Click(object sender, EventArgs e)
        {
            OrdersDetail ordersDetail = new OrdersDetail(this);
            this.Hide();
            ordersDetail.Show();
        }
    }
}
