﻿namespace Webshop
{
    partial class Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox_Categories = new System.Windows.Forms.ComboBox();
            this.listBox_Categories = new System.Windows.Forms.ListBox();
            this.dataGridView_Products = new System.Windows.Forms.DataGridView();
            this.dataGridView_Orders = new System.Windows.Forms.DataGridView();
            this.button_AddToCart = new System.Windows.Forms.Button();
            this.button_BackToPreviousForm = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_OrderQuantity = new System.Windows.Forms.TextBox();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_order = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.orderDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productCategoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.detailNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.detailPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.detailQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Products)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Orders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productCategoriesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox_Categories
            // 
            this.comboBox_Categories.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productCategoriesBindingSource, "CategoryName", true));
            this.comboBox_Categories.FormattingEnabled = true;
            this.comboBox_Categories.Location = new System.Drawing.Point(13, 13);
            this.comboBox_Categories.Name = "comboBox_Categories";
            this.comboBox_Categories.Size = new System.Drawing.Size(185, 21);
            this.comboBox_Categories.TabIndex = 0;
            this.comboBox_Categories.SelectedIndexChanged += new System.EventHandler(this.comboBox_Categories_SelectedIndexChanged);
            // 
            // listBox_Categories
            // 
            this.listBox_Categories.FormattingEnabled = true;
            this.listBox_Categories.Location = new System.Drawing.Point(13, 41);
            this.listBox_Categories.Name = "listBox_Categories";
            this.listBox_Categories.Size = new System.Drawing.Size(185, 394);
            this.listBox_Categories.TabIndex = 1;
            this.listBox_Categories.SelectedIndexChanged += new System.EventHandler(this.listBox_Categories_SelectedIndexChanged);
            // 
            // dataGridView_Products
            // 
            this.dataGridView_Products.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Products.Location = new System.Drawing.Point(205, 41);
            this.dataGridView_Products.Name = "dataGridView_Products";
            this.dataGridView_Products.Size = new System.Drawing.Size(583, 127);
            this.dataGridView_Products.TabIndex = 2;
            // 
            // dataGridView_Orders
            // 
            this.dataGridView_Orders.AllowUserToAddRows = false;
            this.dataGridView_Orders.AllowUserToDeleteRows = false;
            this.dataGridView_Orders.AutoGenerateColumns = false;
            this.dataGridView_Orders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Orders.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.detailNameDataGridViewTextBoxColumn,
            this.detailPriceDataGridViewTextBoxColumn,
            this.detailQuantityDataGridViewTextBoxColumn});
            this.dataGridView_Orders.DataSource = this.orderDetailsBindingSource;
            this.dataGridView_Orders.Location = new System.Drawing.Point(205, 231);
            this.dataGridView_Orders.Name = "dataGridView_Orders";
            this.dataGridView_Orders.ReadOnly = true;
            this.dataGridView_Orders.Size = new System.Drawing.Size(583, 138);
            this.dataGridView_Orders.TabIndex = 3;
            // 
            // button_AddToCart
            // 
            this.button_AddToCart.Location = new System.Drawing.Point(358, 202);
            this.button_AddToCart.Name = "button_AddToCart";
            this.button_AddToCart.Size = new System.Drawing.Size(75, 23);
            this.button_AddToCart.TabIndex = 4;
            this.button_AddToCart.Text = "Add to Cart";
            this.button_AddToCart.UseVisualStyleBackColor = true;
            this.button_AddToCart.Click += new System.EventHandler(this.button_AddToCart_Click);
            // 
            // button_BackToPreviousForm
            // 
            this.button_BackToPreviousForm.Location = new System.Drawing.Point(733, 11);
            this.button_BackToPreviousForm.Name = "button_BackToPreviousForm";
            this.button_BackToPreviousForm.Size = new System.Drawing.Size(54, 23);
            this.button_BackToPreviousForm.TabIndex = 5;
            this.button_BackToPreviousForm.Text = "Back";
            this.button_BackToPreviousForm.UseVisualStyleBackColor = true;
            this.button_BackToPreviousForm.Click += new System.EventHandler(this.button_BackToPreviousForm_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(221, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "All prices are in USD, Weights are in gram";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(596, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(345, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Quantity (integer only)";
            // 
            // textBox_OrderQuantity
            // 
            this.textBox_OrderQuantity.Location = new System.Drawing.Point(460, 176);
            this.textBox_OrderQuantity.Name = "textBox_OrderQuantity";
            this.textBox_OrderQuantity.Size = new System.Drawing.Size(100, 20);
            this.textBox_OrderQuantity.TabIndex = 9;
            this.textBox_OrderQuantity.TextChanged += new System.EventHandler(this.textBox_OrderQuantity_TextChanged);
            this.textBox_OrderQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_OrderQuantity_KeyPress);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(599, 202);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(103, 23);
            this.button_Delete.TabIndex = 10;
            this.button_Delete.Text = "Delete from Cart";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_order
            // 
            this.button_order.Location = new System.Drawing.Point(416, 384);
            this.button_order.Name = "button_order";
            this.button_order.Size = new System.Drawing.Size(180, 42);
            this.button_order.TabIndex = 11;
            this.button_order.Text = "ORDER";
            this.button_order.UseVisualStyleBackColor = true;
            this.button_order.Click += new System.EventHandler(this.button_order_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(460, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Price do not include tax";
            // 
            // orderDetailsBindingSource
            // 
            this.orderDetailsBindingSource.DataSource = typeof(Webshop.OrderDetails);
            // 
            // productCategoriesBindingSource
            // 
            this.productCategoriesBindingSource.DataSource = typeof(Webshop.ProductCategories);
            // 
            // detailNameDataGridViewTextBoxColumn
            // 
            this.detailNameDataGridViewTextBoxColumn.DataPropertyName = "DetailName";
            this.detailNameDataGridViewTextBoxColumn.HeaderText = "DetailName";
            this.detailNameDataGridViewTextBoxColumn.Name = "detailNameDataGridViewTextBoxColumn";
            this.detailNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // detailPriceDataGridViewTextBoxColumn
            // 
            this.detailPriceDataGridViewTextBoxColumn.DataPropertyName = "DetailPrice";
            this.detailPriceDataGridViewTextBoxColumn.HeaderText = "DetailPrice";
            this.detailPriceDataGridViewTextBoxColumn.Name = "detailPriceDataGridViewTextBoxColumn";
            this.detailPriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // detailQuantityDataGridViewTextBoxColumn
            // 
            this.detailQuantityDataGridViewTextBoxColumn.DataPropertyName = "DetailQuantity";
            this.detailQuantityDataGridViewTextBoxColumn.HeaderText = "DetailQuantity";
            this.detailQuantityDataGridViewTextBoxColumn.Name = "detailQuantityDataGridViewTextBoxColumn";
            this.detailQuantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_order);
            this.Controls.Add(this.button_Delete);
            this.Controls.Add(this.textBox_OrderQuantity);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_BackToPreviousForm);
            this.Controls.Add(this.button_AddToCart);
            this.Controls.Add(this.dataGridView_Orders);
            this.Controls.Add(this.dataGridView_Products);
            this.Controls.Add(this.listBox_Categories);
            this.Controls.Add(this.comboBox_Categories);
            this.Name = "Order";
            this.Text = "Order";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Products)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Orders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productCategoriesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_Categories;
        private System.Windows.Forms.ListBox listBox_Categories;
        private System.Windows.Forms.DataGridView dataGridView_Products;
        private System.Windows.Forms.DataGridView dataGridView_Orders;
        private System.Windows.Forms.Button button_AddToCart;
        private System.Windows.Forms.Button button_BackToPreviousForm;
        private System.Windows.Forms.BindingSource productCategoriesBindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_OrderQuantity;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_order;
        private System.Windows.Forms.BindingSource orderDetailsBindingSource;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn detailNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn detailPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn detailQuantityDataGridViewTextBoxColumn;
    }
}