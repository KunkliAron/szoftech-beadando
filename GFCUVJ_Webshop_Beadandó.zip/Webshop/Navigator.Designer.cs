﻿namespace Webshop
{
    partial class Navigator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Order = new System.Windows.Forms.Button();
            this.button_OrderDetails = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_Order
            // 
            this.button_Order.Location = new System.Drawing.Point(49, 109);
            this.button_Order.Name = "button_Order";
            this.button_Order.Size = new System.Drawing.Size(78, 67);
            this.button_Order.TabIndex = 0;
            this.button_Order.Text = "Order";
            this.button_Order.UseVisualStyleBackColor = true;
            this.button_Order.Click += new System.EventHandler(this.button_Order_Click);
            // 
            // button_OrderDetails
            // 
            this.button_OrderDetails.Location = new System.Drawing.Point(133, 109);
            this.button_OrderDetails.Name = "button_OrderDetails";
            this.button_OrderDetails.Size = new System.Drawing.Size(78, 67);
            this.button_OrderDetails.TabIndex = 1;
            this.button_OrderDetails.Text = "OrderDetails";
            this.button_OrderDetails.UseVisualStyleBackColor = true;
            this.button_OrderDetails.Click += new System.EventHandler(this.button_OrderDetails_Click);
            // 
            // Navigator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_OrderDetails);
            this.Controls.Add(this.button_Order);
            this.Name = "Navigator";
            this.Text = "Navigator";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_Order;
        private System.Windows.Forms.Button button_OrderDetails;
    }
}