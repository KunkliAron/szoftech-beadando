﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Webshop
{
    public partial class Register : Form
    {
        Form previousform;
        WebshopEntitiesContext context;
        
        public Register(Form previousform)
        {
            InitializeComponent();

            this.previousform = previousform;

            context = new WebshopEntitiesContext();

            context.Users.Load();

            usersBindingSource.DataSource = context.Users.Local;

        }

        private void button_BackToPreviousForm_Click(object sender, EventArgs e)
        {
            this.Hide();

            previousform.Show();
        }

        private void button_Register_Click(object sender, EventArgs e)
        {
            foreach (TextBox textbox in this.Controls.OfType<TextBox>())
            {
                if (textbox.Text == "")
                {
                    MessageBox.Show("You have to fill every textbox to register");
                    return;
                }

            }
            if (context.Users.Where(u => u.Email == textBox_Email.Text).FirstOrDefault() != null)
            {
                MessageBox.Show("Username (email) is already registered");
            }
            else
            {
                Users users = new Users
                {
                    Email = textBox_Email.Text,
                    Password = textBox_Password.Text,
                    Firstname = textBox_Firstname.Text,
                    Lastname = textBox_Lastname.Text,
                    City = textBox_City.Text,
                    ZIPcode = textBox_ZIPcode.Text,
                    Phone = textBox_Phone.Text,
                    Country = textBox_Country.Text,
                    Address = textBox_Address.Text,
                };
                context.Users.Add(users);
                context.SaveChanges();
            
                Clear();
            }
        }

        private void Clear()
        {
            textBox_Email.Text = textBox_Password.Text = textBox_Firstname.Text = textBox_Lastname.Text = textBox_City.Text = textBox_ZIPcode.Text = textBox_Phone.Text = textBox_Country.Text = textBox_Address.Text = "";
        }

        private void textBox_Email_Validating(object sender, CancelEventArgs e)
        {
            Regex regex = new Regex(@"(^$)|(^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$)");

            if (regex.IsMatch(textBox_Email.Text))
            {
                e.Cancel = false;
                label9.Hide();
            }
            else
            {
                e.Cancel = true;
                label9.Text = "Not valid email";
                label9.Show();
            }
        }

        private void textBox_Phone_Validating(object sender, CancelEventArgs e)
        {
            Regex regex = new Regex(@"^[+]?[0-9]{11,16}$");

            if (regex.IsMatch(textBox_Phone.Text))
            {
                e.Cancel = false;
                label11.Hide();
            }
            else
            {
                e.Cancel = true;
                label11.Text = "Not valid phonenumber";
                label11.Show();
            }
            
        }
    }
}
