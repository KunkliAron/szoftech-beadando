﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Webshop
{
    public partial class OrdersDetail : Form
    {
        Form previousform;
        WebshopEntitiesContext context;

        public OrdersDetail(Form previousform)
        {
            InitializeComponent();

            this.previousform = previousform;

            context = new WebshopEntitiesContext();

            context.Orders.Load();
            dataGridView1.DataSource = context.Orders.Local;

            UpdateOrders();
        }

        private void button_BackToPreviousForm_Click(object sender, EventArgs e)
        {
            this.Hide();

            previousform.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            GetOrders();
        }

        private void GetOrders()
        {
            try
            {
                int findOrderID = int.Parse(textBox1.Text);

                var orderList = context.Orders
                    .Where(o => o.OrderUserID == findOrderID )
                    .Select(o => o);

                dataGridView1.DataSource = orderList.ToList();

            }
            catch 
            {

            }
        }

        private void UpdateOrders()
        {
            foreach (var order in context.Orders)
            {
                var result = context.Orders.SingleOrDefault(o => o.OrderID == order.OrderID);

                if (order.OrderDate.AddDays(3) <= DateTime.Now)
                {
                    result.OrderShipped = true;
                }

            }
            context.SaveChanges();
        }
    }
}
