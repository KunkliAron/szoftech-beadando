﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;

namespace Webshop
{
    public partial class Order : Form
    {
        Form previousform;
        WebshopEntitiesContext context;
        private BindingList<OrderDetails> listOrderDetails;
        string currentUserEmail = Main.passingUsername;

        public Order(Form previousform)
        {
            InitializeComponent();

            this.previousform = previousform;

            context = new WebshopEntitiesContext();

            context.ProductCategories.Load();
            context.Products.Load();
            context.Stock.Load();
            context.OrderDetails.Load();

            comboBox_Categories.Items.AddRange(context.ProductCategories.ToArray());
            comboBox_Categories.DisplayMember = "CategoryName";
            listBox_Categories.DisplayMember = "ProductName";
            listBox_Categories.ValueMember = "ProductID";

            listOrderDetails = new BindingList<OrderDetails>();
        }

        private void button_BackToPreviousForm_Click(object sender, EventArgs e)
        {
            this.Hide();

            previousform.Show();
        }

        private void comboBox_Categories_SelectedIndexChanged(object sender, EventArgs e)
        {
            FilterProducts();
        }

        private void FilterProducts()
        {
            try
            {
                var selectedCategory = (ProductCategories)comboBox_Categories.SelectedItem;
           
                var products = context.Products
                    .Where(p => p.ProductCategoryID == selectedCategory.CategoryID);

                listBox_Categories.DisplayMember = "ProductName";
                listBox_Categories.ValueMember = "ProductID";

                listBox_Categories.DataSource = products.ToList();

            }
            catch
            {
                MessageBox.Show("Couldn't filter products");
            }

            
        }

        private void listBox_Categories_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetProductDetail();
        }

        private void GetProductDetail()
        {
            try
            {
                var selectedProduct = (Products)listBox_Categories.SelectedItem;

                var selectedproductdetail = context.Products
                    .Where(p => p.ProductID == selectedProduct.ProductID)
                    .Select(p => new { p.ProductName, p.Size, p.Color, p.Weight, p.Price, p.Stock.Available });
            

                dataGridView_Products.DataSource = selectedproductdetail.ToList();
            }
            catch
            {
                MessageBox.Show("Couldn't load product details");
            }
        }

        private void button_AddToCart_Click(object sender, EventArgs e)
        {
            try
            {
                var selecteditemStock = (Products)listBox_Categories.SelectedItem;

                if (int.Parse(textBox_OrderQuantity.Text) <= selecteditemStock.Stock.Quantity && selecteditemStock.Stock.Available == true)
                {
                    var orderDetail = GetOrderDetails();

                    listOrderDetails.Add(orderDetail);
                    dataGridView_Orders.DataSource = listOrderDetails;
                    context.SaveChanges();
                }
                else
                {
                    MessageBox.Show("Not enough " + selecteditemStock.ProductName + ", only " + selecteditemStock.Stock.Quantity + " are available");
                }

            }
            catch
            {
                MessageBox.Show("Please select an product");
            }
        }

        private OrderDetails GetOrderDetails()
        {
            dataGridView_Orders.DataSource = null;
            int quantity = int.Parse(textBox_OrderQuantity.Text);

            OrderDetails orderDetails = new OrderDetails();
            
            var product = (Products)listBox_Categories.SelectedItem;

            orderDetails.DetailName = product.ProductName;
            orderDetails.DetailPrice = product.Price * quantity;
            orderDetails.DetailQuantity = quantity;
            orderDetails.Products = product;
            orderDetails.Orders = null;

            return orderDetails;
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                dynamic actual = dataGridView_Orders.CurrentRow;
                dataGridView_Orders.Rows.Remove(actual);

            }
            catch (Exception)
            {
                MessageBox.Show("Couldn't delete from cart")
 ;           }
        }

        private void button_order_Click(object sender, EventArgs e)
        {
            try
            {
                if (listOrderDetails.Count == 0)
                {
                    MessageBox.Show("Your cart is empty, please select a product");
                }
                else
                {
                    if (dataGridView_Orders.Rows.Count != 0)
                    {
                        Random random = new Random();
                        int tax = random.Next(5, 25);

                        var user = context.Users
                            .Where(u => u.UsersID == CurrentSession.CurrentUserID)
                            .FirstOrDefault();
 
                        var currentOrder = new Orders
                        {
                            ShippingAdress = user.Address,
                            City = user.City,
                            ZIPcode = user.ZIPcode,
                            Country = user.Country,
                            PhoneNumber = user.Phone,
                            Tax = tax.ToString(),
                            Email = currentUserEmail,
                            OrderDate = DateTime.Now,
                            OrderShipped = false,

                            Users = user,
                        };

                        foreach (var orderDetail in listOrderDetails)
                        {
                            orderDetail.Orders = currentOrder;
                        }
            
                        var orderDetails = context.OrderDetails.AddRange(listOrderDetails);

                        currentOrder.OrderDetails = orderDetails.ToList();

                        context.Orders.Add(currentOrder);
                        context.SaveChanges();

                        OrdersDetail ordersDetail = new OrdersDetail(previousform);
                        ordersDetail.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Your cart is empty, please select a product");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Something went wrong please try again later");
            }
        }

        private void textBox_OrderQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsNumber(ch) && ch != 8 && ch!= 46)
            {
                e.Handled = true;
            }
        }

        private void textBox_OrderQuantity_TextChanged(object sender, EventArgs e)
        {
            if (textBox_OrderQuantity.Text.Contains("."))
            {
                MessageBox.Show("Please use only integer");
                button_AddToCart.Hide();
            }
            else
            {
                button_AddToCart.Show();
            }
        }
    }
}
