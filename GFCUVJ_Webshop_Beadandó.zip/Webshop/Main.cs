﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Webshop
{
    public partial class Main : Form
    {
        WebshopEntitiesContext context;
        public static string passingUsername;

        public Main()
        {
            InitializeComponent();
        }

        private void button_Login_Click(object sender, EventArgs e)
        {
            context = new WebshopEntitiesContext();

            var user = context.Users.Where(u => u.Email == textBox_Username.Text).FirstOrDefault();

            if (user == null)
            {
                MessageBox.Show("User doesn't exist");
            }
            else if (user.Password == textBox_Password.Text)
            {
                CurrentSession.CurrentUserID = user.UsersID;
                Navigator navigator = new Navigator();
                this.Hide();
                navigator.Show();
                passingUsername = textBox_Username.Text;
            }
            else
            {
                MessageBox.Show("Wrong Password");
            }
       
        }

        private void button_Register_Click(object sender, EventArgs e)
        {
            Register register = new Register(this);
            this.Hide();
            register.Show();
        }

        private void textBox_Username_Validating(object sender, CancelEventArgs e)
        {
            Regex regex = new Regex(@"(^$)|(^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$)");

            if (regex.IsMatch(textBox_Username.Text))
            {
                e.Cancel = false;

                if (!String.IsNullOrWhiteSpace(textBox_Username.Text))
                    textBox_Username.BackColor = Color.LightGreen;
                else
                    textBox_Username.BackColor = Color.White;
            }
            else
            {
                e.Cancel = true;
                textBox_Username.BackColor = Color.MediumVioletRed;
            }
        }


        private void textBox_Username_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }
    }
}
